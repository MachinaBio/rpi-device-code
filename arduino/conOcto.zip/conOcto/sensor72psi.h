#define hVersion 'oct'
#define sVersion '001'

///////////////////////////////////////////////////
// Hardware specific configuration
///////////////////////////////////////////////////
/* Set the pins for each of the valves */
const int octoVPins[8] =  {2, 4, 6, 8, 3, 5, 7, 9};
const int octoNValves =    8;

////////////////////////////////////////////////
//  PARAMETERS FOR PID CONTROLLER
////////////////////////////////////////////////

/* The default values for the reservoir PID object */
const ReservoirConfig octoReservoirConfig = {   11, // Pin for the bleed/fill valve 
                                                10, // Pin for the hold valve 
                                                33, // Proportional term
                                                50, // Integral term
                                               0.0 };  // Derivative term
                                               
////////////////////////////////////////////////
//  PARAMETERS FOR PRESSURE SENSOR
////////////////////////////////////////////////

const PressureSensor octoPresureSensor = { A0, // Analog in pin for pressure sensor 
                                         (double) 0.0, // Lower limit of sensor pressure range 
                                         (double) 72.5, // Upper limit of sensor pressure range 
                                        (double) 0.20, // Lower limit of sensor voltage output
                                        (double) 4.70 }; // Upper limit of sensor voltage output

                      
const LCDconfig octoLCD = {2,   // number of rows
                          16,   // number of columns
                        0x50};  // I2C address
