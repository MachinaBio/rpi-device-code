///////////////////////////////////////////////////
// Hardware specific configuration
///////////////////////////////////////////////////
/* Set the pins for each of the valves */
const int valvePins[8] =  {2, 4, 6, 8, 3, 5, 7, 9};
const int addressPins[4] = {A1, A2, A3, A6};


////////////////////////////////////////////////
//  PARAMETERS FOR PID CONTROLLER
////////////////////////////////////////////////
/* The default values for the reservoir PID object */
const ReservoirConfig config = {   11, // Pin for the bleed/fill valve 
                                                10, // Pin for the hold valve 
                                                225000, // Proportional term
                                                341000, // Integral term
                                               0.0 };  // Derivative term
                                               
////////////////////////////////////////////////
//  PARAMETERS FOR PRESSURE SENSOR
////////////////////////////////////////////////
SensorCalibration calibration = { {0.205,4.705,0,0,0}, // sensor voltage. values must be in increasing order
                                  {0,250000,0,0,0},    // pressure reading in pascals
                                  0};                  // number of points
                                  
const PressureSensor mpx = { A0, // Analog in pin for pressure sensor 
                                         (double) 0.0, // Lower limit of sensor pressure range 
                                         (double) 250000.0, // Upper limit of sensor pressure range 
                                        (double) 0.205, // Lower limit of sensor voltage output
                                        (double) 4.705, // Upper limit of sensor voltage output
                                        calibration};
                      
const LCDconfig lcd = {  2,   // number of rows
                         16,   // number of columns
                         0x50};  // I2C address

AquinasGlobal global;
