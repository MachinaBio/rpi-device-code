/**
 * A hardware abstraction class for a pressure reservoir.
 *
 * This class implements a PID controller.
 *
 * @file Reservoir.H
 * @author Carlo Quinonez <cquinonez@ucsd.edu>
 * @version 1.0
 * @section LICENSE
 *This software is Copyright � 2011 The Regents of the University of California. All Rights
 *Reserved.
 *
 *Permission to use, copy, modify, and distribute these design files, software, firmware and
 *documentation for educational, research and non-profit purposes, without fee, and without
 *a written agreement is hereby granted, provided that the above copyright notice, this
 *paragraph and the following three paragraphs appear in all copies.
 *
 *Permission to make commercial use of this software may be obtained by contacting:
 *Technology Transfer Office
 *9500 Gilman Drive, Mail Code 0910
 *University of California
 *La Jolla, CA 92093-0910
 *(858) 534-5815
 *invent@ucsd.edu
 *
 *These design files, software, firmware and documentation are copyrighted by The Regents
 *of the University of California. The software program and documentation are supplied "as is",
 *without any accompanying services from The Regents. The Regents does not warrant that the
 *operation of the program will be uninterrupted or error-free. The end-user understands that
 *the program was developed for research purposes and is advised not to rely exclusively on
 *the program for any reason.

 *IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 *SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE
 *USE OF THESE DESIGN FILES, SOFTWARE, FIRMWARE AND DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 *CALIFORNIA HAS BEEN ADVISED OFTHE POSSIBILITY OF SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA
 *SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS
 *ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE
 *MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.  
 */
#ifndef VSRESERVOIR
#define VSRESERVOIR

#include "WProgram.h"

#ifndef PID_v1_h
#error The PID library must be included from your sketch.
#endif

#define PIDUPDATECYCLE 500
#define PRESSUREWINDOWWIDTH 16

/**
 * Structure containing low-level parameters for the pressure controller
 * 
 * @param drivePin Pin number of the bleed/fill-rate control valve
 * @param holdPin Pin number of the hold pressure control valve
 * @param pTerm Proportional term
 * @param iTerm Integrative term
 * @param dTerm Derivative term
 */
struct ReservoirConfig {
  int    drivePin;
  int    holdPin;
  double pTerm;
  double iTerm;
  double dTerm;
};

/**
 * Structure containing low-level tuning parameters for pressure sensor
 * 
 * @param pin Pin number of the pressure sensor
 * @param maxADCVolts Maximum voltage reading of ADC
 * @param minPressure Lowest pressure in PSIG sensor is capable of reading
 * @param maxPressure Maximum pressure in PSIG sensor is capable of reading
 * @param minFSVolts Voltage output of sensor at minPressure
 * @param maxFSVolts Voltage output of sensor at maxPressure
 */
struct PressureSensor {
  int    pin;
  double minPressure;
  double maxPressure;
  double minFSVolts;
  double maxFSVolts;
};

class PressureReservoir
{  
public:
  /**
   * Setpoint in PSIG for the reservoir.
   * 
   */
  double setpoint;         // in PSI

  /**
   * Current reservoir pressure in PSIG.
   * 
   */
  double currentPressure;  // in PSI

  /**
   * Constructor initializes the PID control algorithim and sets relevant pin identities.
   * 
   * @param setpoint The setpoint of the reservoir in PSI
   * @param sensor Low-level parameters for pressure sensor
   * @param tuning Low-level parameters for pressure controller
   */
  PressureReservoir(PressureSensor newSensor, ReservoirConfig newReservoir)
: 
//    algorithm(&currentPressure, &controlOutput, &setpoint, reservoir.pTerm , reservoir.iTerm, reservoir.dTerm, DIRECT),
  algorithm(&currentPressure, &controlOutput, &setpoint, 100.0 , 10, 0.0, DIRECT),
    sensor(newSensor), controlOutput(0), currentPressure(0),setpoint(0),
    reservoir(newReservoir)
    {
//      controlOutput = 0; // set default valves
//      currentPressure = 0;

      // Change PWM frequency for Timer2 if the holdPin is 11
//      if (reservoir.holdPin == 10) TCCR1B = TCCR1B & 0b11111000 | 0x05;
	TCCR1B = TCCR1B & 0b11111000 | 0x05;


      digitalWrite(reservoir.drivePin, LOW); 
      digitalWrite(reservoir.holdPin, LOW);

      pinMode(reservoir.drivePin, OUTPUT);
      pinMode(reservoir.holdPin, OUTPUT); 

      /* Set the output range of the control algorithm.
       +1 -> fill up at the fastest rate possible
       0 -> seal the reservoir
       -1 -> bleed pressure from the reservoir at the fastest rate possible */
      algorithm.SetOutputLimits(-255, 255);
      algorithm.SetSampleTime(500);
      algorithm.SetMode(AUTOMATIC);

      nextUpdateTime = millis() + PIDUPDATECYCLE;
    }

  /**
   * Updates the pressure reservoir controller if needed.
   *
   */
  void update()
  {
    if ( millis() > nextUpdateTime  )  // only update every 100msecs
    {
      readPressure(); 
      algorithm.Compute();
      setOutput();
      
      nextUpdateTime = millis() + PIDUPDATECYCLE;
    }
  }
private:
  double controlOutput;     // from -255 to 255
  long int nextUpdateTime;
  PressureSensor sensor;
  ReservoirConfig reservoir;
  PID algorithm;
 
  /**
   * Takes the output from the ADC and scales it accordingly. 
   *
   * @param Pressure in counts (0-1023)
   * @return Pressure in PSIG 
   */
  double countsToPressure (double counts)
  {
   double voltageSpan = sensor.maxFSVolts - sensor.minFSVolts;
   double volts = counts * 5.0 /1023.0;
   double pressureSpan = sensor.maxPressure - sensor.minPressure;     
  
   double scaledPressure = sensor.minPressure + (pressureSpan * ( volts - sensor.minFSVolts ) / voltageSpan  );
 //  double scaledPressure = pressureSpan * ( volts - 0.23 ) / voltageSpan;
 
   return scaledPressure;
   // return 10.123;
  }

  /**
   * Reads the ADC and sets currentPressure
   *
   */
  void readPressure()
  {
    double accumulator = 0;
    // take multiple readings of the pressure sensor and sum them all up
    for (int i=0; i < PRESSUREWINDOWWIDTH; i++)
      accumulator += analogRead( sensor.pin );

	accumulator /= PRESSUREWINDOWWIDTH;
    // scale and store pressure reading
   currentPressure = countsToPressure( accumulator ); 
   // currentPressure = countsToPressure( 1023.0); 
  }


  /**
   * Sets the positions of the hold and drive valves 
   *
   * @param Pressure in counts ADC reading (0-1023)
   * @return Pressure in PSIG
   */
  void setOutput()
  {
    if (controlOutput < 0) {
      digitalWrite(  reservoir.drivePin, HIGH); // decrease reservoir pressure 
      analogWrite( reservoir.holdPin, 255 - abs(controlOutput)); // Set the duty cycle of the pressure hold pin to the calculated value
    }
    else {
      digitalWrite(  reservoir.drivePin, LOW); // increase reservoir pressure 
      analogWrite( reservoir.holdPin, 255 - controlOutput); // Set the duty cycle of the pressure hold pin to the calculated value
    } 
  }
};

#endif







