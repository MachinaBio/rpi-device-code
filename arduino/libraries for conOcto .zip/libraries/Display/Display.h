/**
 * A hardware abstraction class for the LCD display
 *
 * This class handles periodic updating of on-screen information
 * and initializaiton of an NHD i2C LCD
 *
 * @file Display.H
 * @author Carlo Quinonez <cquin donez@ucsd.edu>
 * @version 1.0
 * @section LICENSE
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details at
 * http://www.gnu.org/copyleft/gpl.html
 */
#ifndef VSDISPLAY
#define VSDISPLAY

#ifndef LCDi2cNHD_h
#error The LCDi2cNHD library must be included from your sketch.
#endif

#include "WProgram.h"

// Update the screen every 500ms, ie. 2Hz
#define DISPLAYUPDATETIME 500

#define MAXVALVENUM 8

#define BRIGHTBACKLIGHT 8
#define DIMBACKLIGHT 3
/* Set the LCD backlight brightness level, value between 1 to 8 This command set the LCD display backlight brightness level, the value is between 1 to 8. Default brightness value is 1.
*/

#define BRIGHTCONTRAST 50
#define DIMCONTRAST 30
/* Set the display contrast, value between 1 to 50 This command sets the LCD character display contrast, the contrast setting is between 1 to 50, where 50 is the highest contrast. Default contrast value is 40. */

/**
 * Structure containing low-level configuration parameters for lcd display
 * 
 * @param rows Number of rows on LCD display
 * @param columns Number of columns on LCD display
 * @param i2cAddress 8-bit I2C address of LCD display
 */
struct LCDconfig {
  uint8_t rows;
  uint8_t columns;
  uint8_t i2cAddress;
};

class Display {	 
public:
 /**
   * Bus Address.
   * 
   */
    char moduleAddress;
    float setPressure, currentPressure;
  
  /**
   * Constructor that initializes the display and sets the module address.
   * 
   * @param params Low-level parameters for configuration of NHD I2C Display
   * @param moduleAddress Single character address of this valve stack module
   */
	Display( LCDconfig params, char address) :
	lcd(params.rows, params.columns, params.i2cAddress >> 1, 0), 
	backlight(true), 
	_flash(false), 
	nextUpdateTime(0),
	moduleAddress(address)
	{
	moduleName[0]='v';
	moduleName[1]='s';
 	moduleName[2]='O';
	moduleName[3]='c';
	moduleName[4]='t';
	moduleName[5]='o';				
	}
	
/**
 * Initializes lcd. This method is required because we cannot communicate from global constructors.
 *
 */
   void begin() {
	  lcd.init();
	  lcd.clear();
	  lcd.setDelay(0,0);
	  lcd.blink_off(); 
	  lcd.cursor_off();
	  setBright();
	  loadInvertedDigits();
	  lcd.clear();
	  splash();
	  delay(2000);
	  lcd.clear();
   }

  /**
   * Updates the screen.
   *
   */
  void update()
  {
	if (millis() > nextUpdateTime ) {
	  nextUpdateTime = millis() + DISPLAYUPDATETIME;
	  lcd.clear();
	  drawValves();
	  drawAddress();
	  drawPressures();
	  updateBacklight();
	}
  }

  /**
   * Update the pressure registers.
   *
   * @param actual Current reservoir pressure in PSI
   * @param setpoint Reservoir pressure setpoint in PSI
   */
  void setPressures (double newPressure, double setPressure)
  {
  
  }

  /**
   * Update the valves registers
   *
   * @param newValveStates[] Receptacle for valve states
   */
  void setValves (boolean newValveStates[])
  {
	for(int i=0; i < MAXVALVENUM; i++)
	{
	  valveStates[i] = newValveStates[i];
	}
  }


  /**
   * Flashes the LCD backlight
   *
   */

  void flash ()	 {
	_flash=true;
  }

private:
  ///////////////////////////////////////////////////
  // Private METHODS
  ///////////////////////////////////////////////////
  char moduleName[7];
  LCDi2cNHD lcd;

  long int nextUpdateTime;
  boolean backlight, _flash;

  boolean valveStates[MAXVALVENUM];

  /* DRAWPRESSURE :: Draws contents of the pressure registers */
  void drawPressures () {
  char buffer[6];
	lcd.setCursor(0,0);
	lcd.print("S ");
	dtostrf( setPressure, 5, 2, buffer);
	lcd.print(buffer);
	lcd.setCursor(1,0);
	lcd.print("R ");
	dtostrf( currentPressure, 5, 2, buffer);
	lcd.print(buffer);
  }

  /* DRAWVALVES :: Draws contents of the valve register on the screen */
  void drawValves () {
	lcd.setCursor(1,8);
	for( int i=0; i < 8; i++) {
	  if ( valveStates[i] ) {
	  	lcd.print(i+1) ; }
	  else {
	  	lcd.print('x') ;
	  	}
	}
  }

  /* DRAWADDRESS :: Draw the address register on the screen */
  void drawAddress ()
  {
	lcd.setCursor(0,15);
	lcd.print(moduleAddress);

	lcd.setCursor(0,8);
	lcd.print(moduleName);
  }

  /* BACKLIGHT :: Flashes the screen backlight if necessary, otherwise sets it to max brightness */
  void updateBacklight()
  {
	/* If _flash is set, invert _backlight */
	if (_flash) backlight = !backlight;
	else backlight = true;

	/* Set the backlight according to _backlight */
	if (backlight) lcd.setBacklight(BRIGHTBACKLIGHT);
	else lcd.setBacklight(DIMBACKLIGHT);
	_flash = false;
  }

  /* SPLASH :: Draws the splash screen */
  void splash() {
	lcd.clear();
	lcd.setCursor(0,0);
	lcd.print("vsOcto Module");
	lcd.setCursor(1,0);
	lcd.print("Designed at UCSD");
  }
  
    /* SETBRIGHT :: Sets the bright font */
  void setBright() {
	  lcd.setBacklight(BRIGHTBACKLIGHT);
	  lcd.setContrast(BRIGHTCONTRAST);

  }
  
      /* SETDIM :: Sets the dim font */
  void setDim() {
	  lcd.setBacklight(DIMBACKLIGHT);
	  lcd.setContrast(DIMCONTRAST);

  }

  void loadInvertedDigits()
  {
	byte customCharacter[8];

	// Create and save an inverted 1
	customCharacter[0] = B11011;
	customCharacter[1] = B10011;
	customCharacter[2] = B11011;
	customCharacter[3] = B11011;
	customCharacter[4] = B11011;
	customCharacter[5] = B11011;
	customCharacter[6] = B10001;
	customCharacter[7] = B11111;

	lcd.load_custom_character(0, customCharacter);

	// Create and save an inverted 2
	customCharacter[0] = B10001;
	customCharacter[1] = B01110;
	customCharacter[2] = B11110;
	customCharacter[3] = B11101;
	customCharacter[4] = B11011;
	customCharacter[5] = B10111;
	customCharacter[6] = B00000;
	customCharacter[7] = B11111;
	lcd.load_custom_character(1, customCharacter);

	// Create and save an inverted 3
	customCharacter[0] = B00000;
	customCharacter[1] = B11101;
	customCharacter[2] = B11011;
	customCharacter[3] = B11101;
	customCharacter[4] = B11110;
	customCharacter[5] = B01110;
	customCharacter[6] = B10001;
	customCharacter[7] = B11111;
	lcd.load_custom_character(2, customCharacter);

	// Create and save an inverted 4
	customCharacter[0] = B11101;
	customCharacter[1] = B11001;
	customCharacter[2] = B10101;
	customCharacter[3] = B01101;
	customCharacter[4] = B00000;
	customCharacter[5] = B11101;
	customCharacter[6] = B11101;
	customCharacter[7] = B11111;

	lcd.load_custom_character(3, customCharacter);
	// Create and save an inverted 5
	customCharacter[0] = B00000;
	customCharacter[1] = B01111;
	customCharacter[2] = B00001;
	customCharacter[3] = B11110;
	customCharacter[4] = B11110;
	customCharacter[5] = B01110;
	customCharacter[6] = B10001;
	customCharacter[7] = B11111;
	lcd.load_custom_character(4, customCharacter);

	// Create and save an inverted 6
	customCharacter[0] = B11001;
	customCharacter[1] = B10111;
	customCharacter[2] = B01111;
	customCharacter[3] = B00001;
	customCharacter[4] = B01110;
	customCharacter[5] = B01110;
	customCharacter[6] = B10001;
	customCharacter[7] = B11111;
	lcd.load_custom_character(5, customCharacter);

	// Create and save an inverted 7
	customCharacter[0] = B00000;
	customCharacter[1] = B11110;
	customCharacter[2] = B11101;
	customCharacter[3] = B11101;
	customCharacter[4] = B11011;
	customCharacter[5] = B11011;
	customCharacter[6] = B11011;
	customCharacter[7] = B11111;
	lcd.load_custom_character(6, customCharacter);

	// Create and save an inverted 8
	customCharacter[0] = B10001;
	customCharacter[1] = B01110;
	customCharacter[2] = B01110;
	customCharacter[3] = B10001;
	customCharacter[4] = B01110;
	customCharacter[5] = B01110;
	customCharacter[6] = B10001;
	customCharacter[7] = B11111;
	lcd.load_custom_character(7, customCharacter);
  }
};

#endif



































