/**
 * A hardware abstraction class for the valvestack communication bus
 *
 * This class handles valvestack bus communications and maintains an
 * internal register of the current output valve states.
 *
  *
 * @file CommandBus.H
 * @author Carlo Quinonez <cquinonez@ucsd.edu>
 * @version 1.0
 * @section LICENSE
 *This software is Copyright � 2011 The Regents of the University of California. All Rights
 *Reserved.
 *
 *Permission to use, copy, modify, and distribute these design files, software, firmware and
 *documentation for educational, research and non-profit purposes, without fee, and without
 *a written agreement is hereby granted, provided that the above copyright notice, this
 *paragraph and the following three paragraphs appear in all copies.
 *
 *Permission to make commercial use of this software may be obtained by contacting:
 *Technology Transfer Office
 *9500 Gilman Drive, Mail Code 0910
 *University of California
 *La Jolla, CA 92093-0910
 *(858) 534-5815
 *invent@ucsd.edu
 *
 *These design files, software, firmware and documentation are copyrighted by The Regents
 *of the University of California. The software program and documentation are supplied "as is",
 *without any accompanying services from The Regents. The Regents does not warrant that the
 *operation of the program will be uninterrupted or error-free. The end-user understands that
 *the program was developed for research purposes and is advised not to rely exclusively on
 *the program for any reason.

 *IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
 *SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE
 *USE OF THESE DESIGN FILES, SOFTWARE, FIRMWARE AND DOCUMENTATION, EVEN IF THE UNIVERSITY OF
 *CALIFORNIA HAS BEEN ADVISED OFTHE POSSIBILITY OF SUCH DAMAGE. THE UNIVERSITY OF CALIFORNIA
 *SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED HEREUNDER IS
 *ON AN "AS IS" BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE
 *MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.  
 */
#ifndef VSCOMMANDBUS
#define VSCOMMANDBUS

#include "WProgram.h"

#define BUSSPEED 9600
#define MAXPAYLOADLENGTH 8
#define MAXNVALVES 8

#define VALIDCOMMANDCHARACTERS "vs"
#define VALIDPAYLOADCHARACTERS "1234567890."

class CommandBus {
public:
  /**
   * Timeout for watchdog in milliseconds.
   *
   */
  long int watchdog;
  
  /**
   * Command has been queued and is waiting for processing.
   *
   */
  boolean valid;
  
 //   boolean valveRegister[8];
    boolean valveRegister[MAXNVALVES];
    double setpointRegister;
    
     /* id is a single char */
  char moduleAddress; 


  /**
   * Constructor that initializes the network bus.
   * 
   * @param moduleAddress Single character address of this valve stack module
   */
  CommandBus(char newAddress, int newNValves) :
  moduleAddress(newAddress),
  nValves(newNValves)
  {
    for (int i=0; i< MAXNVALVES; i++ ) valveRegister[i] = false;
//    for (int i=0; i< 8; i++ ) valveRegister[i] = false;
  } 

  /**
   * Performs periodic tasks required for bus activity.
   *
   */
  void begin()
  {
    Serial.begin(BUSSPEED);
        watchdog=5000;
        resetWatchdog();
        clearCommand();
        Serial.flush();
   }
  
  /**
   * Performs periodic tasks required for bus activity.
   *
   */
  void update()
  {
    if (Serial.available()>0) resetWatchdog();  // reset the watchdog if there's any data on the bus
// Serial.print("Update\n");

    while (Serial.available() > 0)
    {
      push(Serial.read());
      if ( _command == 'v' && valid ) updateValves();  // handle valve command internally
      if ( _command == 's' && valid ) updateSetpoint();  // handle valve command internally
     if ( valid ) break;
    }
  }

  /**
   * Returns the current command from the bus, or "?" is there is no valid command.
   *
   * @return The current command
   */
  char getCommand()
  {
    if (valid == false) return '?';
    clearCommand();
    return _command;
  }

  /**
   * Gets the payload from the last command. Returns false is there is no valid command.
   *
   * @param valveArray Receptacle for the payload data
   * @return Was there a valid command waiting on the bus?
   */

  boolean getPayload(char _payload[])
  {
    if (valid == false) return false;
    for (int i=0; i< index; i++)
    {
      _payload[i] = payloadBuffer[i];
    }
    return true;
  }

  /**
   * Gets contents of the valve state register
   *
   * @param valveArray boolean array containing the valve states
   */
 /* broken
 void getValves(boolean valveArray[])
  {
    for(int i=0; i < nValves; i++)
    {
      valveArray[i] = valveRegister[i];
    }
    Serial.print("Get Valves\n");
  }
  */ 

  /**
   * Checks status of watchdog timer.
   *
   * @return Has the watchdog elapsed?
   */
  boolean failsafe()
  {
    if (watchdogTimeout < millis() ) return true;
    return false;
  }

  /**
   * Returns the single character address
   *
   * @return Module address
   */
  char getID()
  {
    return moduleAddress;
  }


private:
  /* number of milliseconds before bus fails */
  long int watchdogTimeout; 

  /* The number and states of output solenoid valves */
  int nValves;

  /*  Number of bytes left in the incoming command. */
  char _command;
  boolean commandExpected;
  int nBytesExpecting;

  /* Private stores for incoming command buffer */
  char payloadBuffer[MAXPAYLOADLENGTH];
  int index;

  // PUSH ::  Adds serialData to the stack as well as echoing it to upstream serial bus.
  void push(char serialData)
  {
    Serial.print(serialData); 
    /* Were we expecting anything in particular? */
    if (commandExpected) receiveCommand(serialData);	
    else if (nBytesExpecting > 0) receivePayload(serialData);
    else if (serialData == moduleAddress)  {
      valid = false;
      nBytesExpecting = MAXPAYLOADLENGTH;
      commandExpected = true;
    }
  }
  
  void receivePayload(char serialData)
  {
    String validCharacters = String(VALIDPAYLOADCHARACTERS);
    
    if ( validCharacters.indexOf(serialData) == -1) {
    	clearCommand();
    	return; }
    
  	payloadBuffer[index] = serialData;
    ++index;
    if (--nBytesExpecting == 0) valid=true; // if that was the last byte, set valid  
  }
  
    void receiveCommand(char serialData)
  {
    String validCharacters = String(VALIDCOMMANDCHARACTERS);
    
    if ( validCharacters.indexOf(serialData) == -1) {
    	clearCommand();
    	return; }
    _command = serialData;
    	commandExpected = false;}
  
  
  
  void resetWatchdog()
  {
    watchdogTimeout = millis() + watchdog;
  }

  // UPDATEVALVES :: Update internal valve states from payload area.
  void updateValves()
  {
  
//  Serial.print("UpdateValves\n ");

    for(int i=0; i < nValves;  i++)
    {
      valveRegister[i] = false;
        if ( payloadBuffer[i] == '1' ) valveRegister[i] = true;
    }
    clearCommand();
  }

  // CLEARCOMMAND :: Resets the command parser.
  void clearCommand()
  {
    valid=false;
    nBytesExpecting=0;
    index=0;
  }

 // CLEARCOMMAND :: Resets the command parser.
  void updateSetpoint()
  {
   setpointRegister = atof(payloadBuffer);
       clearCommand();
  }
};

#endif
















